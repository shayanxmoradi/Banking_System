create procedure insert_data(IN a character varying, IN b character varying, IN c integer)
    language sql
as
$$
INSERT INTO student(sname, city, clg_id) VALUES (a,b,c);
--INSERT INTO student VALUES (b);
$$;

alter procedure insert_data(varchar, varchar, integer) owner to shayan;

