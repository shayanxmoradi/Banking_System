create procedure insert_data4(IN a character varying, IN b character varying, IN c integer)
    language sql
as
$$
INSERT INTO student(sname, city, clg_id) VALUES (a,b,c);
$$;

alter procedure insert_data4(varchar, varchar, integer) owner to shayan;

